create
    definer = root@localhost procedure addOperation(IN supplierId int, IN customerId int, IN weight int,
                                                    IN chargeMode int, IN QMoney int, IN SMoney int, IN YMoney int,
                                                    IN destinationId int, IN destination varchar(64), IN originId int,
                                                    IN origin varchar(64), OUT result int)
BEGIN
	DECLARE opid int;
	declare originWay VARCHAR(6);
	declare destinationWay VARCHAR(6);
	SELECT `name` FROM t_address WHERE id=originId INTO originWay;
	SELECT `name` FROM t_address WHERE id=destinationId INTO destinationWay;
	INSERT INTO t_operation SET supplierId = supplierId,customerId=customerId,weight=weight,chargeMode=chargeMode,QMoney=QMoney,SMoney=SMoney,YMoney=YMoney,destinationId=destinationId,destination=destination,originId=originId,origin=origin;
	SELECT row_count() INTO result;
	SELECT LAST_INSERT_ID() INTO opid;
	UPDATE t_operation SET way=CONCAT(originWay,'->',destinationWay) WHERE id=opid;
	
END;

